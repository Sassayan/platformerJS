const game = new Phaser.Game(800, 600, Phaser.AUTO, '', {
    preload: preload,
    create: create,
    update: update
})
    let score = 0;
    let scoreText;
    let platforms;
    let player;
    let diamonds;
    let cursors;
    let bomb;


function preload () {
    game.load.image('sky1', 'assets/sky1.png')
    game.load.image('ground', 'assets/platform.png')
    game.load.image('platform1', 'assets/platform1.png')
    game.load.image('platform2', 'assets/platform2.png')
    game.load.image('ground2', 'assets/ground2.png')
    game.load.image('bomb', 'assets/bomb.png')
    game.load.image('diamond', 'assets/diamond.png')
    game.load.spritesheet('woof', 'assets/woof.png', 32,32)
    
}

function create  () {
    game.physics.startSystem(Phaser.Physics.ARCADE);

    game.add.sprite(0, 0, 'sky1');

    platforms = game.add.group();
    platforms.enableBody = true;

    const ground = platforms.create(0, game.world.height -74, 'ground2');
    ground.body.immovable = true;

    let ledge = platforms.create(400, 430, 'platform2');
    ledge.body.immovable = true;

    ledge = platforms.create(0, 350, 'platform1');
    ledge.body.immovable = true;

    ledge = platforms.create(150, 250, 'platform2');
    ledge.body.immovable = true;

    

    player = game.add.sprite(32, game.world.height - 150, 'woof');
    game.physics.arcade.enable(player);
    player.body.bounce.y = 0.2;
    player.body.gravity.y = 800;
    player.body.collideWorldBounds = true;

    player.animations.add('left', [0, 1], 10, true);
    player.animations.add('right', [2, 3], 10, true);
    

    diamonds = game.add.group();
    diamonds.enableBody = true;

    for(let i = 0; i < 12; i++) {
        const diamond = diamonds.create(i * 70, 0, 'diamond')
        diamond.body.gravity.y = 1000;
        diamond.body.bounce.y = 0.3 + Math.random() * 0.2;
    }


    bombs = game.add.group();
    bombs.enableBody = true;
    
    
    for(let i = 0; i < 3; i++) {
        const bomb = bombs.create (i * 190, 0, 'bomb')
        bomb.body.gravity.y = 1000;
        bomb.body.bounce.y = 0.2 + Math.random() * 0.5;
    }

scoreText = game.add.text(16, 16, '', { fontSize: '32px', fill: '#000'});
cursors = game.input.keyboard.createCursorKeys();

}



function update () {
    game.physics.arcade.collide(player, platforms); //the two collide
    game.physics.arcade.collide(diamonds, platforms);
    game.physics.arcade.collide(bombs, platforms);
    
    game.physics.arcade.overlap(player, diamonds, collectDiamond, null, this);
    game.physics.arcade.overlap(player, bombs, hitBomb, null, this);
    
    player.body.velocity.x = 0;
   

    if(cursors.left.isDown) {
        player.body.velocity.x = -150
        player.animations.play('left')
    } else if (cursors.right.isDown) {
        player.body.velocity.x = 150
        player.animations.play('right')
    } else {
        player.animations.stop()
    }
    if(cursors.up.isDown && player.body.touching.down) {
        player.body.velocity.y = -420
    }
    if(score === 120) {
        alert ("Thanks for playing !")
        score = 0;
    }
}

function collectDiamond (player, diamond) {
    diamond.kill();

    score += 10; //quand diamant collecté, +10
    scoreText.text = 'Score:' + score;
}


function hitBomb (player, bomb) {
   bomb.kill();
   /* player.tint = 0xff0000 j'ai essayé de faire en sorte que le personnage soit rouge puis revienne à sa couleur originale quand il touche une bombe, mais je n'ai pas réussi à trouver la fonction qui le permettait. 
   J'ai tenté setTimeout sans succès en crééant une fonction 'playerTint'  et une condition comme ceci :   if(player.tint === 0xff000) {
}else {
 player.tint = 0xffffff
}
   */
   score -= 20;
   scoreText.text = 'Score:' + score;
}
 




   
